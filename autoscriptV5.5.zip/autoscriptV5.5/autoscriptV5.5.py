from headers.config import *
#—————————————检查依库赖项、tesseract引擎————————————————
from headers.requirements import *
#——————本文件直接用到的库（第三方 import 必须排在 requirements 之后，缺包才已装好）——————
import os,threading,time
import PySimpleGUI as sg            #用于创建图形界面
import pywinctl as pwc              #检测窗口
#————————————————————UI界面——————————————————
from headers.UI_interface import *
#————————————————在游戏中生成键鼠输入————————————————————
from headers.input_control import *
#——————————————————————————————————————————————————————
from headers.log import *
from headers.image_detection import *
from headers.ship_move import *
from headers.ship_attack import *

def partsDone(window):
    '''
    研发配件
    '''
    ScreenState.screenshot = getScreen(window)
    found, pos = hasImage("autoresearch", 0.95,ScreenState.screenshot)
    if found:
        click(pos)
        time.sleep(5)
        for i in range(3):
            pressWithDelay('esc', 0.1, 0.5)

def leave_battle():
    '''
    快速退出战局
    '''
    pressWithDelay('esc')
    time.sleep(1)
    click((640,498))
    time.sleep(1)
    click((580,468))
    time.sleep(10)

def WTScript(window):
    ScreenState.screenshot = getScreen(window)
    windowName = window.title
    print(windowName)
    if windowName.__contains__("等"):
        print("正在匹配中")
        time.sleep(5)
        return
    elif not (windowName.__contains__("试") or windowName.__contains__("战") or windowName.__contains__("载")):
        # We are at the hanger. Try to enter a game first
        naval, _ = hasImage("naval", 0.95, ScreenState.screenshot, "未检测到海战！可能被阻挡或未调成海战")
        if naval:
            #加入战斗的过程
            enter, pos = hasImage("enterbattle", 0.95, ScreenState.screenshot)
            if enter:
                if time.time()>=ProgramData.t_start + ProgramData.t_run:
                    ProgramData.isRunning = False
                if not ProgramData.isRunning:
                    endScript()
                
                if ProgramData.money_start==None:
                    ProgramData.money_start=recognize_money_amount(ScreenState.screenshot,debug=False)
                click(pos)
                time.sleep(5)
                return

            download, pos = hasImage("downloadprompt", 0.98, ScreenState.screenshot)
            if download:
                # If the texture download happens to be there, close it
                click(pos)
                return

            exitout, pos = hasImage("exitout", 0.92, ScreenState.screenshot)
            if exitout:
                click(pos)
                return

            pressWithDelay('esc')
            send_input_mouse(100*(random.random()-0.5),100*(random.random()-0.5))
            time.sleep(2)
            
        else:
            #结算画面

            ScreenState.screenshot = getScreen(window)
            crates, _ = hasImage("crates", 0.95, ScreenState.screenshot)
            if crates:
                # unlocked crates
                log("获得作战物资")

            task, task_pos = hasImage("taskcomplete", 0.95, ScreenState.screenshot)
            if task:
                click(task_pos)
                log("已完成每日任务")
                return

            found, pos = hasImage("newshipresearched", 0.97, ScreenState.screenshot)
            if found:
                log("新战舰研发已完成")
                if ProgramData.purchase:
                    click(pos)
                else:
                    pressWithDelay("esc")
                return
            
            if ProgramData.purchase:
                ship, ship_pos = hasImage("purchase_ship",0.95, ScreenState.screenshot)
                if ship:
                    click(ship_pos)
                    log("已购买新战舰")
                    return
                else:
                    pressWithDelay("esc")

            found, pos = hasImage("confirm", 0.97, ScreenState.screenshot)
            if found:
                click(pos)
                return

            found, pos = hasImage("autoresearch", 0.95, ScreenState.screenshot)
            if found:
                partsDone(window)
                return

            found, pos = hasImage("cancelsmall", 0.98, ScreenState.screenshot)
            if found:
                click(pos)
                return

            found, pos = hasImage("exitout", 0.92, ScreenState.screenshot)
            if found:
                click(pos)
                return

            pressWithDelay('esc')
            send_input_mouse(100*(random.random()-0.5),100*(random.random()-0.5))
            time.sleep(2)
    
    elif windowName.__contains__("试"):
        # We are in testing mode. Under this mode it only fires to check if the attack pattern works
        print('界面为试驾，测试移动与攻击')
        
        stop_event = threading.Event()
        
        prevent_obstacles_progress = threading.Thread(target=hide_obstacles,args=(stop_event,))
        prevent_obstacles_progress.start()

        prevent_aground_progress = threading.Thread(target=prevent_aground,args=(stop_event,))
        prevent_aground_progress.start()

        prevent_out_progress = threading.Thread(target=prevent_out,args=(stop_event, True))
        prevent_out_progress.start()

        prevent_escape_progress = threading.Thread(target=prevent_escape,args=(stop_event,))
        prevent_escape_progress.start()

        AimStatus.i = 0
        # 新对局：重置比例尺识别状态（不同地图比例尺可能不同，每局重新识别，最多3次）
        MapState.scale_data = MapState.scale_width = None
        MapState.scale_try = 0
        # 新对局：重置出生点识别状态（每局重新识别，最多3次）
        MapState.spawn_red = MapState.spawn_blue = None
        MapState.spawn_try = 0
        while windowName.__contains__("试"):
            #每轮刷新标题：windowName 是进函数时的快照，试驾结束回到机库后条件仍为真，
            #不刷新就会一直对着机库调用 attack_strategy，在机库里乱发键鼠
            windowName = window.title
            stop_sign = attack_strategy(window)

            if stop_sign:
                leave_battle()
                break        
        stop_event.set()
        while (prevent_obstacles_progress.is_alive() or prevent_aground_progress.is_alive()
               or prevent_out_progress.is_alive() or prevent_escape_progress.is_alive()):
            print('waiting for prevent threads to stop')
            time.sleep(1)
        # 试驾结束：机动线程已停，重置识别状态，避免残留到下一局
        MapState.scale_data = MapState.scale_width = None
        MapState.scale_try = 0
        MapState.spawn_red = MapState.spawn_blue = None
        MapState.spawn_try = 0

        time.sleep(100)

    elif windowName.__contains__("载"):
        # We are loading into one game
        print('界面正在载入')
        time.sleep(4)

    elif windowName.__contains__("战"):
        # We are currently in a game
        # First sleep for a while
        time.sleep(5)
        ScreenState.screenshot = getScreen(window)
        print('战斗开始，等待自动出生')
        # Then, let it auto spawn to avoid being locked on
        while True:
            ScreenState.screenshot = getScreen(window)
            spawn, _ = hasImage("spawn", 0.97, ScreenState.screenshot, "等待中……")
            if not spawn:
                cont, cont_pos = hasImage("continue",0.95,ScreenState.screenshot)
                if cont:
                    #如果不小心按到esc打开菜单界面要回来。
                    click(cont_pos)
                    continue
                break
            time.sleep(5)

        log("加入战斗")
        ProgramData.t_temp_start=time.time()
        # 真正打起来才算一局：匹配成功但被取消、或匹配后没进战斗都不计
        ProgramData.game_number += 1
        # After getting closer to the battlefield, start maneuvering
        stop_event = threading.Event()
        move_strategy_progress=threading.Thread(target=move_strategy,args=(stop_event,))
        move_strategy_progress.start()

        prevent_obstacles_progress = threading.Thread(target=hide_obstacles,args=(stop_event,))
        prevent_obstacles_progress.start()

        prevent_aground_progress = threading.Thread(target=prevent_aground,args=(stop_event,))
        prevent_aground_progress.start()

        prevent_out_progress = threading.Thread(target=prevent_out,args=(stop_event, True))
        prevent_out_progress.start()

        prevent_escape_progress = threading.Thread(target=prevent_escape,args=(stop_event,))
        prevent_escape_progress.start()

        print('开火')
        AimStatus.i = 0
        # 新对局：重置比例尺识别状态（不同地图比例尺可能不同，每局重新识别，最多3次）
        MapState.scale_data = MapState.scale_width = None
        MapState.scale_try = 0
        # 新对局：重置出生点识别状态（每局重新识别，最多3次）
        MapState.spawn_red = MapState.spawn_blue = None
        MapState.spawn_try = 0
        # Lock on to the enemy and open fire
        while windowName.__contains__("战"):
            windowName = window.title
            stop_sign = attack_strategy(window)
            if stop_sign:
                leave_battle()
                break
        stop_event.set()
        while (move_strategy_progress.is_alive() or prevent_obstacles_progress.is_alive() or
               prevent_aground_progress.is_alive() or prevent_out_progress.is_alive()):
            print('waiting for progress to stop')
            time.sleep(1)
        # 对局结束：机动线程均已退出，重置识别状态，避免残留到下一局
        MapState.scale_data = MapState.scale_width = None
        MapState.scale_try = 0
        MapState.spawn_red = MapState.spawn_blue = None
        MapState.spawn_try = 0
        # game is over
        log("结束战斗，等待结算")
        ProgramData.t_temp_end=time.time()
        if (ProgramData.t_temp_start!=None and ProgramData.t_temp_end!=None):
            temp=ProgramData.t_temp_end-ProgramData.t_temp_start
            print("对局时间：",temp)
            ProgramData.t_inbattle+=temp
        else:
            print("对局时间未成功计算")
        ProgramData.t_temp_start = None
        ProgramData.t_temp_end = None
        # wait for the points
        time.sleep(5)


def anchorWindow(window):
    '''
    move war thunder to the top left of the screen
    '''
    global windowIsAnchored
    if windowIsAnchored:
        try:
            window.moveTo(0, 0)
            time.sleep(0.5)
        except:
            windowIsAnchored = False

def StartScript():
    ProgramData.t_start = time.time()
    print("start time:",ProgramData.t_start)

    # detect if the current window is war thunder. If not, don't input anything to avoid accidents
    while True:
        window = pwc.getActiveWindow()
        if window is None:
            continue
        windowName = window.title
        if windowName.__contains__("War Thunder"):
            anchorWindow(window)
            WTScript(window)
            time.sleep(0.5)
        else:
            print("未检测到战争雷霆！")
            time.sleep(3)


def endScript(auto_end=True):
    '''
    退出脚本程序，若进行了对局则记录：
    脚本运行时间
    战斗数目
    初末态银狮数量，收益
    '''
    ProgramData.t_end = time.time()
    log("立即退出")
    if ProgramData.game_number>0:
        if ProgramData.t_end and ProgramData.t_start:
            ProgramData.t_total=ProgramData.t_end-ProgramData.t_start
            log("脚本运行时间 "+str(int(ProgramData.t_total))+" s")
        if ProgramData.t_inbattle!=0:
            log("对局内时间 "+str(int(ProgramData.t_inbattle))+" s")
            log("时间利用率 "+str(int(100*ProgramData.t_inbattle/ProgramData.t_total))+" %")
        log("战斗数目    "+str(ProgramData.game_number))

        if ProgramData.money_start!=None:
            log("起始银狮数 "+str(ProgramData.money_start))
        else:
            log("起始银狮数无法读取，可能是对局中途开启")
        if auto_end:
            #O7：退出时焦点可能不在游戏上，先按标题找到战争雷霆窗口再截图，
            #否则截到的是别的程序画面，银狮收益会算错
            wt_window = find_wt_window()
            if wt_window is None:
                log("未找到战争雷霆窗口，终止时未读取到银狮数")
            else:
                ProgramData.money_end = recognize_money_amount(getScreen(wt_window),debug=False)
                log("终止银狮数 "+str(ProgramData.money_end))
        else:
            log("手动关闭，自行检查收益。")
        if auto_end and ProgramData.money_start is not None and ProgramData.money_end is not None:
            log("银狮收益 "+str(ProgramData.money_end-ProgramData.money_start))
    f.flush()
    f.close()
    os._exit(0)

def main():
    #C6：环境准备（依赖 + Tesseract-OCR）已在 `from headers.requirements import *` 的
    #import 阶段做完，这里不用再调——放到 import 阶段是为了让任何 import 本工程的程序
    #都不会带着"缺包/缺引擎"继续跑。缺失时那里会先弹窗征询是否下载安装（UAC 授权），
    #用户拒绝就照常继续（比例尺识别不可用），不再直接退出进程。
    sg.theme('Reddit')
    SGwindow = sg.Window("Naval Script", layout=Script_UI_layout, finalize=True)

    root = SGwindow.TKroot
    root.update_idletasks()
    screen_w = root.winfo_screenwidth()
    screen_h = root.winfo_screenheight()
    win_w = root.winfo_width()
    win_h = root.winfo_height()
    margin = 50
    x = screen_w - win_w - margin
    root.geometry(f"+{x}+{margin}")
    root.update_idletasks()

    SGwindow2 = "SGwindow2 has not been established"

    app = threading.Thread(target=StartScript,daemon=True)

    while True:
        window, event, values = sg.read_all_windows(timeout=UPDATE_INTERVAL)
        #print(window,event,values)
        if window == SGwindow:
            instruction = Script_UI(SGwindow,event,values)
            if instruction == "EndScript":
                endScript(False)
            elif instruction == "StartScript":
                app.start()
            elif instruction == "StartDemonstrate":
                if not ProgramData.isDemostrating:
                    ProgramData.isDemostrating = True
                    # PySimpleGUI 主题
                    sg.theme('Reddit')
                    SGwindow2 = sg.Window('实时坐标地图', demostrate_UI_layout, finalize=True)

                    root = SGwindow2.TKroot
                    root.update_idletasks()

                    win_w2 = root.winfo_width()
                    win_h2 = root.winfo_height()

                    root.geometry(f"+{int(screen_w - win_w2 - margin)}+{int(win_h +2*margin)}")
                    root.update_idletasks()

                    #出生点图标只在此处预加载一次（去黑底+裁剪+base64），
                    #之后 update_demonstrate_UI 每帧直接复用缓存，不再读盘
                    prepare_spawn_icons()

        elif window == SGwindow2:
            instruction = demostrate_UI(SGwindow2,event,values)
            if instruction == "EndDemonstrate":
                ProgramData.isDemostrating = False
                SGwindow2.close()
        if event == sg.TIMEOUT_EVENT and ProgramData.isDemostrating:
            #isDemostrating 在 EndDemonstrate 时已复位，避免对已关闭窗口做 update
            update_demonstrate_UI(SGwindow2)

if __name__ == '__main__':
    main()