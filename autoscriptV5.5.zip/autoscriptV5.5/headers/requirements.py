#标准库部分（本模块自己用到的）
import ctypes
import subprocess
import sys
import importlib.util
import os
import urllib.request

def ensure_dependencies():
    # 映射：import名称 -> pip安装名称
    REQUIRED_PACKAGES = {
        "keyboard": "keyboard",
        "pyautogui": "PyAutoGUI",
        "pywinctl": "PyWinCtl",
        "PIL": "Pillow",
        "cv2": "opencv-python",
        "PySimpleGUI": "PySimpleGUI==4.60.5.1",
        "numpy": "numpy",
        "pytesseract": "pytesseract",
        "matplotlib": "matplotlib",
    }
    missing = []
    for module_name, pip_name in REQUIRED_PACKAGES.items():
        # 只探测"装没装"，**不真的把模块导进来**：
        # 原来用 importlib.import_module() 会把 9 个库全部执行一遍，
        # matplotlib 光 base 包就要 ~490 ms（它在本工程里只有 temp 脚本用）。
        # find_spec() 只查有没有，重库不会再被白加载。
        try:
            found = importlib.util.find_spec(module_name) is not None
        except (ImportError, ValueError):
            found = False
        if not found:
            missing.append(pip_name)
    
    if missing:
        print(f"检测到缺失依赖: {', '.join(missing)}")
        print("正在自动安装，请稍候...")
        subprocess.check_call(
            [sys.executable, "-m", "pip", "install"] + missing
        )
        print("依赖安装完成！")
    else:
        print("所有依赖已就绪")

# 环境准备一律留在 import 阶段，分两步、都在本模块内完成：
#   1) ensure_dependencies()：先把 REQUIRED_PACKAGES 里缺的包装上，
#      下面的第三方 import 依赖它（缺包时 import 会直接抛 ImportError，
#      比"先装再导"失败得更早也更难懂）；
#   2) ensure_environment()：见文件末尾（放在最后是因为它要用到 sg）。
# 这样任何入口（主脚本、工具脚本、测试）只要 import 本模块，就一定是"环境就绪"的，
# 不会出现"某个程序 import 进来却因为没装模块当场报错"。
# 两步都只做检查 + 必要准备，不退出进程；缺 Tesseract 时先弹窗征询，用户拒绝就照常继续。
ensure_dependencies()

# 第三方：本模块自己只用 PySimpleGUI（弹窗征询），其余一概不 import。
# 重库（cv2 / numpy / pytesseract / matplotlib / pyautogui / pywinctl / keyboard / PIL）
# 谁用谁在自己的文件里 import —— 安装由上面的 REQUIRED_PACKAGES 统一保证，
# 不需要在这里全局引入。以前这里是"转发站"，把 9 个库灌给所有 import 本模块的文件，
# 结果谁依赖什么都看不出来，matplotlib 更是全程没人用却每次启动都要加载。
# ⚠️ 第三方 import 必须排在 ensure_dependencies() 之后。
import PySimpleGUI as sg            #用于创建图形界面

#Tesseract-OCR：用于识别小地图比例尺数字
TESSERACT_DIR = r"C:\Program Files\Tesseract-OCR"
TESSERACT_URL = ("https://github.com/UB-Mannheim/tesseract/releases/download/"
                 "v5.4.0.20240606/tesseract-ocr-w64-setup-5.4.0.20240606.exe")


def ensure_environment():
    '''
    Tesseract-OCR 环境准备：检查 → 征询 → 下载 → 安装 → 挂 PATH，全在这一个函数里。
    （Python 依赖那部分在 ensure_dependencies()，见文件顶部。）

    已装：只把目录挂进 PATH（幂等，重复调用不会堆出重复项）后返回 True。
    未装：先问用户要不要装——能用界面就弹窗，否则退回控制台 input，两者都不可用（无人
    应答）时**默认拒绝**；用户说不装就直接返回 False，主流程照常继续（只有比例尺识别退化）。
    同意才联网下载安装，且**只提权"安装器"本身**（PowerShell RunAs，UAC 仍是权限请求但可拒绝）：
    旧写法 ShellExecuteW(..., "runas", sys.executable, ...) 是重启整个脚本 + sys.exit()，
    等于把决定权交给 UAC 弹窗，点"否"就在任何界面出现之前静默消失（表现成"双击没反应"）。

    本模块在 import 阶段自调用一次（见文件末尾），所以不需要各入口自己记得调：
    import 本模块 = 环境已就绪。
    '''
    exe = os.path.join(TESSERACT_DIR, "tesseract.exe")
    if os.path.exists(exe):
        if TESSERACT_DIR not in os.environ.get("PATH", ""):
            os.environ["PATH"] += os.pathsep + TESSERACT_DIR
        return True

    #征询用户许可
    question = ("未检测到 Tesseract-OCR 引擎（用于识别小地图比例尺数字，缺失时该功能不可用）。\n\n"
                "需要联网下载约 50 MB 安装包，并以管理员权限安装。\n是否现在安装？")
    try:
        agreed = sg.popup_yes_no(question, title="环境准备") == "Yes"
    except Exception:
        try:
            agreed = input(question + "\n[y/N] ").strip().lower() in ("y", "yes")
        except Exception:
            agreed = False
    if not agreed:
        print("已跳过 Tesseract-OCR 安装：比例尺识别将不可用，其余功能不受影响。")
        return False

    installed = False
    try:
        installer = os.path.join(os.environ["TEMP"], "tesseract-setup.exe")
        print("正在下载 Tesseract-OCR 安装包……")
        urllib.request.urlretrieve(TESSERACT_URL, installer)
        if ctypes.windll.shell32.IsUserAnAdmin():
            subprocess.run([installer, "/S"], check=True)
        else:
            #请求管理员权限：Windows 会弹出 UAC 确认框（用户仍可拒绝）
            print("正在请求管理员权限以安装 Tesseract-OCR……")
            subprocess.run(
                ["powershell", "-NoProfile", "-Command",
                 "Start-Process -FilePath '{}' -ArgumentList '/S' -Verb RunAs -Wait".format(installer)],
                check=True
            )
        installed = os.path.exists(exe)
        print("Tesseract-OCR 安装至 " + TESSERACT_DIR if installed
              else "Tesseract-OCR 安装未生效，请手动检查。")
    except Exception as e:
        print("Tesseract-OCR 安装失败：{}（比例尺识别将不可用）".format(e))

    if installed and TESSERACT_DIR not in os.environ.get("PATH", ""):
        os.environ["PATH"] += os.pathsep + TESSERACT_DIR
    return installed


# import 阶段就把环境备好：任何程序 import 本模块（主脚本 / 工具 / 测试）都不会
# 在后续 import 第三方库或调用 OCR 时撞上"没装"。
# 必须放在所有 def 之后：它用到 sg（弹窗征询）、ctypes、subprocess 等。
ensure_environment()
