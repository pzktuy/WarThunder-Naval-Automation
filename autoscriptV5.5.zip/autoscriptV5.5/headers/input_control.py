import ctypes                       #用于生成鼠标连续移动
from ctypes import wintypes         #用于生成鼠标连续移动
import time,math,pyautogui,keyboard,random
from headers.config import MouseSensitivity
# Windows API 常量
INPUT_MOUSE = 0
MOUSEEVENTF_MOVE = 0x0001
MOUSEEVENTF_ABSOLUTE = 0x8000

class MOUSEINPUT(ctypes.Structure):
    _fields_ = [
        ("dx", wintypes.LONG),
        ("dy", wintypes.LONG),
        ("mouseData", wintypes.DWORD),
        ("dwFlags", wintypes.DWORD),
        ("time", wintypes.DWORD),
        ("dwExtraInfo", ctypes.POINTER(wintypes.ULONG)),
    ]

class INPUT(ctypes.Structure):
    _fields_ = [("type", wintypes.DWORD), ("mi", MOUSEINPUT)]

def send_input_mouse_system(dx, dy, absolute=False):
    """
    使用 SendInput 发送底层鼠标输入
    absolute=True 时，dx/dy 是 0-65535 的绝对坐标
    """
    flags = MOUSEEVENTF_MOVE
    if absolute:
        flags |= MOUSEEVENTF_ABSOLUTE
    
    mi = MOUSEINPUT(dx, dy, 0, flags, 0, None)
    inp = INPUT(INPUT_MOUSE, mi)
    
    ctypes.windll.user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))

def send_input_mouse(dx, dy, absolute=False,speed = 3000):
    if absolute:
        send_input_mouse_system(dx, dy, absolute=True)
        return

    distance = math.hypot(dx, dy)
    if distance < 1:
        return

    duration = max(0.03, min(distance / speed, 1.0))
    steps = max(2, int(duration / 0.005))

    # 随机弯曲，约为移动距离的 ±8%
    ux, uy = dx / distance, dy / distance
    px, py = -uy, ux
    curve = distance * random.uniform(-0.08, 0.08)
    cx, cy = dx * random.uniform(0.35, 0.65) + px * curve, dy * random.uniform(0.35, 0.65) + py * curve

    start = time.perf_counter()
    last_x = last_y = 0.0

    for i in range(1, steps + 1):
        t = i / steps
        s = t * t * (3 - 2 * t)  # 平滑加速、减速
        x = 2 * (1 - s) * s * cx + s * s * dx
        y = 2 * (1 - s) * s * cy + s * s * dy

        mx, my = round(x - last_x), round(y - last_y)
        if mx or my:
            send_input_mouse_system(mx, my)

        last_x, last_y = x, y
        target = start + duration * i / steps
        while time.perf_counter() < target:
            time.sleep(0.0005)

#鼠标平滑移动到屏幕绝对坐标
def move_mouse_to(x, y, speed=500):
    '''
    用曲线把鼠标平滑移动到屏幕绝对坐标 (x, y)，speed 单位为像素/秒。
    (x, y) 与 pyautogui.moveTo 同一坐标系（本进程已被 pyautogui 设为 DPI 感知，
    故是物理像素空间），因此 location 类参数可直接传入。
    曲线、分步、节流全部复用 send_input_mouse，走的是 SendInput 注入。
    注意：相对注入会经过系统指针加速曲线，落点可能偏离目标若干像素，
    所以末尾再用一次 SetCursorPos 把落点精确对齐，保证 click 点得中。
    '''
    cx, cy = pyautogui.position()
    send_input_mouse((x - cx)*MouseSensitivity.sensibility_x, 
                     (y - cy)*MouseSensitivity.sensibility_y, 
                     speed=speed)
    pyautogui.moveTo(x, y)

#鼠标点击
def click(location=None,duration=0.2):
    # click a certain location on the screen
    if location:
        #move_mouse_to(location[0], location[1])
        pyautogui.moveTo(location[0],location[1],duration=0.3)
    time.sleep(0.1)
    pyautogui.mouseDown(button='left')
    time.sleep(duration)
    pyautogui.mouseUp(button='left')

#键盘按键
def pressWithDelay(c, d=0.1, t=0.1):
    # press the button c, for d seconds, and wait t seconds
    keyboard.press(c)
    time.sleep(d)
    keyboard.release(c)
    time.sleep(t)
