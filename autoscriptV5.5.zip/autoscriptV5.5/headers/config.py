import os,time

current_dir =  os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

#小地图截图区域 (left, top, width, height)；UI 画布尺寸按 width/height 同步
MAP_REGION = (1052, 526, 218, 218)

#出生点图标模板（red=敌方、blue=友方），文件位于 model/ 下；
#演示界面用它把检测到的出生点标注到画布上。键名与 MapState.spawn_* 对应。
SPAWN_ICON_FILES = {'red': 'template_red_ship', 'blue': 'template_blue_ship'}

#脚本运行
class ProgramData:
    t_start = time.time()
    t_end = None                #初末态时间
    t_total = None

    t_temp_start = None
    t_temp_end = None
    t_inbattle = 0
    money_start = None
    money_end = None            #初末态银狮数量
    t_run = 30000               #脚本最长运行时间
    game_number = 0             #进行对局数量
    isRunning = False           #是否进入新的对局
    isDemostrating = False
    purchase = True

class ScreenState:
    screenshot = None

    target_status = None
    aim_scr = None
    # aim_direction_scr = None  # 全项目无读无写，2026-09-11 改为注释
    aim_distance_scr = None
    target_crew_status = None
    
    nav_scr = None
    nav_agr_scr = None

#小地图相关状态：截图、比例尺、出生点
class MapState:
    battle_map = None

    scale_data = None           #小地图比例尺数值（米），预期 300-10000
    scale_width = None          #比例尺刻线长度（像素）
    scale_try = 0               #本局已尝试识别比例尺的次数（每局最多3次）

    spawn_red = None            #敌方出生点(红色舰船图标)在小地图内的归一化坐标 [(x,y), ...]
    spawn_blue = None           #友方出生点(蓝色舰船图标)在小地图内的归一化坐标 [(x,y), ...]
    spawn_try = 0               #本局已尝试识别出生点的次数（每局最多3次）

class ShipData:
    ship_type = "destroyer"
    turntime = 8
    gotime = 30
    reloadtime = 6
    shoot_round = 1
    speed = 0

class ShipStatus:
    ship_position_x = -1
    ship_position_y = -1
    ship_direction = -1

    # turning_to_battle = 0      # 全项目无读无写，2026-09-11 改为注释
    moving_strategy = False
    preventing_out = 0
    preventing_obstacles = 0
    preventing_aground = False  #协调船只机动权限
    preventing_escape = 0       #朝向敌方出生点转向：0 未执行，-1 左转，+1 右转

#开火相关状态
class AimStatus:
    aim_direction = -1
    aim_distance = -1
    
    shoot_distance_min = 1
    shoot_distance_max = 7
    normal_y_correction = 17

    i = 0   #已射击轮数

    locking_target = False
    decide_to_shoot = False
    shoot_fail = 0
    turning_to_shoot = 0        #齐射转向：0 未转向，-1 左转，+1 右转；prevent_escape 非 0 时让出舵
    turned_to_shoot = False

class MouseSensitivity:
    sensibility_x=1
    sensibility_y=1

windowIsAnchored = True

