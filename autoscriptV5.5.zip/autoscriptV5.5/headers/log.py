import time,os
from headers.config import current_dir

#若battlelog不存在则创建文件夹
if not os.path.exists(current_dir+'/battlelog'):
    os.makedirs(current_dir+'/battlelog')
curr_date = time.strftime("%Y%m%d", time.localtime())
f = open(current_dir+f'/battlelog/{curr_date}_log.txt', 'a+')   #日志文件
def log(message):
    # put the log in the GUI and the text log
    print(message)
    curr_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    try:
        f.write("[" + curr_time + "] " + str(message) + "\n")
        f.flush()
    except:
        print("日志写入失败（可能是编码问题）")