from headers.config import *
from headers.log import *
import numpy as np
import cv2
from PIL import Image
import pytesseract
import pyautogui
import pywinctl as pwc
import re

#截屏整个游戏屏幕画面
def getScreen(window, edge=(0,0,0,0)):
    left, top = window.topleft
    right, bottom = window.bottomright
    img = pyautogui.screenshot(
    region=(left-edge[0], top-edge[1],
            right-left+edge[0]+edge[2], bottom-top+edge[1]+edge[3]))
    return img


#按标题查找战争雷霆窗口
#退出结算等场景焦点可能已经不在游戏上，此时不能用 getActiveWindow（会截到别的程序画面）
def find_wt_window(title="War Thunder"):
    try:
        windows = pwc.getWindowsWithTitle(title)
    except Exception:
        return None
    return windows[0] if windows else None


#游戏窗口是否仍存在、且位于前台
#游戏崩溃/切屏后 isActive 会变成 False 甚至直接抛异常，一律当成"不在前台"处理
def window_active(window):
    try:
        return bool(window is not None and window.isActive)
    except Exception:
        return False


#进行图形识别
#匹配成功返回 (True, (x, y))：x,y 是模板中心在 location 图片内的像素坐标；失败返回 (False, None)。
#位置数据不再写全局变量，由调用方直接接住再传给 click，避免多线程下被别的匹配结果覆盖。
#debug 默认 True：保留原有的每次打印（排查识别问题时最直观），需要清屏时传 False。
def hasImage(name, threshold,location, message=None, debug=True):
    #截图保持 PIL 的原样（RGB），改由"模板"翻成 RGB 与截图对齐：
    #相关性对通道置换不变，只要两边同一套通道序即可，这样每次调用省掉对整张截图的 cvtColor
    location_cv2 = np.array(location)
    if location_cv2.ndim == 3 and location_cv2.shape[2] == 4:
        #RGBA/BGRA 截图统一成三通道（丢 alpha），否则与三通道模板类型不符
        location_cv2 = cv2.cvtColor(location_cv2,cv2.COLOR_RGBA2RGB)
    #读模板用 np.fromfile + imdecode：cv2.imread 在 Windows 上读非 ASCII 路径（本工程路径含中文）会静默返回 None，
    #紧接着 matchTemplate 就报 "type == _templ.type()" 断言失败
    try:
        targetImg = cv2.imdecode(np.fromfile(current_dir+"/model/"+name+".png", dtype=np.uint8), cv2.IMREAD_COLOR)
    except (OSError, ValueError):
        targetImg = None
    if targetImg is None:
        log("模板读取失败：model/"+name+".png（文件缺失或无法解码）")
        return False, None
    #imdecode 出来是 BGR，翻成 RGB 与上面的截图对齐（必须连续内存，否则 matchTemplate 报错）
    targetImg = np.ascontiguousarray(targetImg[..., ::-1])
    result = cv2.matchTemplate(location_cv2, targetImg, cv2.TM_CCORR_NORMED)
    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)
    if debug:
        print(name + "\t" + str(max_val) + str(max_loc)+ "\t" + str(max_val > threshold))

    height, width, channel = targetImg.shape
    ul = max_loc
    lr = (ul[0] + width, ul[1] + height)
    center = (int((ul[0] + lr[0]) / 2), int((ul[1] + lr[1]) / 2))
    if max_val > threshold:
        return True, center
    else:
        if message is not None:
            log(message)
        return False, None

#提取图片中某种特定颜色，处理图片
#识别图中？色区域，非？色区域变成？？色
def Get_Color_IMG(img, target_color,background_color, threshold):
    #识别图中目标色区域，非目标色区域变成背景色
    if img.mode != 'RGB':
        img = img.convert('RGB')

    pixels = np.array(img)

    #颜色距离用整数比较（等价于 sqrt(sum(d**2)) <= threshold，但省掉 float64 临时数组和 sqrt）：
    #差值先存 int16 省一半内存，平方前必须抬到 int32（255**2*3 会溢出 int16）
    diff = pixels.astype(np.int16) - np.array(target_color, dtype=np.int16)
    distance2 = np.square(diff, dtype=np.int32)
    mask = np.sum(distance2, axis=2) <= threshold * threshold

    #非目标色变背景色
    height, width = pixels.shape[:2]  # 获取尺寸（兼容灰度/RGB/RGBA）
    result = np.full((height, width, 3), background_color, dtype=np.uint8)
    result[mask] = pixels[mask]

    return Image.fromarray(result)

#识别 War Thunder 界面中"加入战斗"按钮右侧的银币数目。
#识别 ScreenState.screenshot
def recognize_money_amount(img,debug=False):
    # 银币数字固定区域 (基于 1266x750 分辨率)
    # 裁剪坐标 (左, 上, 右, 下)
    crop_box = (765, 60, 832, 78)
    num_crop = img.crop(crop_box)
    if debug:
        num_crop.save(current_dir+"/temp/money_amount_crop.png")
    # 转为灰度图
    gray = num_crop.convert('L')
    arr = np.array(gray)
    
    # 二值化：数字是浅色，背景是深色
    # 阈值100能稳定分离数字和背景
    binary = (arr > 100).astype(np.uint8) * 255
    binary_img = Image.fromarray(binary)
    
    # OCR 识别，psm 6 适合单行文本
    text = pytesseract.image_to_string(
        binary_img, 
        config='--psm 8 -c tessedit_char_whitelist=0123456789,'
    )
    
    # 清理结果：去除空白，去掉逗号，转int
    text = text.strip().replace(',', '')

    try:
        return int(text)
    except (ValueError, TypeError):
        return None

#识别准星下方距离坐标
def get_aim_distance(img):
    gray = np.array(img.convert("L"))
    gray = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    binary = (gray > 110).astype(np.uint8) * 255
    text = pytesseract.image_to_string(binary, config="--psm 7 -c tessedit_char_whitelist=0123456789").strip()
    if not text.isdigit():
        return None
    return int(text) / 100

#识别目标乘员状态（"当前/总数"），例如 222/273
#img 接 ship_attack 截下的 PIL.Image（ScreenState.target_crew_status）
#读出 "int/int" 形式返回 (当前, 总数) 两个 int；读不出（含 a1>a2 这种明显读错）返回 None
def recognize_target_crew_status(img,debug=False):
    #灰度 → 3 倍灰度插值放大 → Otsu 反色（白底黑字）后交给 tesseract。
    #文字只有十来像素高，原分辨率下 tesseract 容易把 2 读成 7，放大后笔形才够清楚。
    #阈值不写死：实测背景亮度整体漂移 ±30、对比度砍半时固定阈值(170)会读成 "272" 或直接读空，
    #Otsu 由直方图自己定阈，这些扰动下都能读全。
    gray = np.array(img.convert("L"))
    gray = cv2.resize(gray, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    _, binary = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    text = pytesseract.image_to_string(
        255 - binary,
        config="--psm 7 -c tessedit_char_whitelist=0123456789/").strip()
    if debug:
        print("target_crew_status OCR:", repr(text))

    #整串必须恰好是 "数字/数字"：两侧位数不限（222/2731 是合法读法，不做位数相等的要求），
    #夹带其它字符或读出空串才算失败
    matched = re.fullmatch(r"(\d+)\s*/\s*(\d+)", text)
    if matched is None:
        return None
    current, total = int(matched.group(1)), int(matched.group(2))
    #当前乘员不可能多于总数：a1>a2 只能是把 / 读串了或某个数字读错，按识别失败处理，交上层重试
    if current > total:
        return None
    return current, total

#识别小地图中旋转的船只标志
# ============================================================
# 预计算箭头模板
# ============================================================
def _prepare_arrow(name):
    #从本地 PNG 读取 9x8 箭头模板，提取黄/白掩码，整张作为模板。
    ref = cv2.cvtColor(np.array(Image.open(current_dir+"/model/"+name+".png").convert("RGB")),
                       cv2.COLOR_RGB2BGR)

    # 黄/白掩码（排除黑边/背景像素，只保留参与匹配的箭头像素）
    hsv = cv2.cvtColor(ref, cv2.COLOR_BGR2HSV)
    mask = cv2.bitwise_or(
        cv2.inRange(hsv, np.array([15, 100, 80]), np.array([45, 255, 255])),
        cv2.inRange(hsv, np.array([0, 0, 200]), np.array([179, 60, 255])),
    )
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8), iterations=1)
    mask = cv2.dilate(mask, np.ones((3, 3), np.uint8), iterations=1)

    return ref, mask

TEMPLATE = dict()
MASK = dict()
TEMPLATE["ship_icon_in_map"],MASK["ship_icon_in_map"] = _prepare_arrow("ship_icon_in_map")

def detect_arrow(target_image,name,angle_step=10):
    """
    在target_image内查找name图标。

    参数
    ----
    target_image : PIL.Image
        待检测的完整截图（内存中的 PIL 格式）。
    minimap_box : tuple
        小地图在截图中的像素范围 (left, top, right, bottom)。
    angle_step : int
        方向搜索步进（度），默认 10。

    返回
    ----
    dict 或 None
        relative     : 箭头中心在小地图内的相对位置 (x, y)，范围 [0, 1]
        pixel        : 箭头中心在整张截图中的像素坐标 (x, y)
        direction_deg: 箭头方向，0° = 向上，90° = 向右
        score        : 匹配得分
    """

    # 裁出小地图
    mini = cv2.cvtColor(np.array(target_image), cv2.COLOR_RGB2BGR)
    mh, mw = mini.shape[:2]

    # 旋转模板匹配（步进 angle_step 度）
    best = {'score': -1.0}
    h, w = TEMPLATE[name].shape[:2]
    for ang in range(0, 360, angle_step):
        c = (w // 2, h // 2)
        R = cv2.getRotationMatrix2D(c, -ang, 1.0)
        ca, sa = abs(R[0, 0]), abs(R[0, 1])
        nw, nh = int(h * sa + w * ca), int(h * ca + w * sa)
        R[0, 2] += nw / 2 - c[0]
        R[1, 2] += nh / 2 - c[1]
        rt = cv2.warpAffine(TEMPLATE[name], R, (nw, nh),
                            borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        rm = cv2.warpAffine(MASK[name], R, (nw, nh),
                            borderMode=cv2.BORDER_CONSTANT, borderValue=0)
        if cv2.countNonZero(rm) < 10:
            continue
        _, mv, _, ml = cv2.minMaxLoc(cv2.matchTemplate(mini, rt, cv2.TM_CCOEFF_NORMED, mask=rm))
        if mv > best['score']:
            best = {'score': mv, 'loc': ml, 'tw': rt.shape[1], 'th': rt.shape[0], 'ang': ang}

    if best['score'] < 0.35:
        print(name,"旋转匹配结果：","cannot find")
        return None

    cx = best['loc'][0] + best['tw'] / 2
    cy = best['loc'][1] + best['th'] / 2
    
    return {
        'relative': (cx / mw, cy / mh),
        'pixel': (cx, cy),
        'direction_deg': best['ang'] % 360,
        'score': float(best['score']),
    }

#检测战术地图中的比例尺（右下角：数值文字 + 其正下方一条纯黑横线）
def detect_scale(img,debug=False):
    #输入img 是 BGR 的 numpy 数组（cv2.imread / cvtColor 的结果，不是 PIL.Image）
    h, w = img.shape[:2]
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # ========== 1. 右下角 100x20 区域 ==========
    scale_x1, scale_y1 = w - 100, h - 20
    scale_x2, scale_y2 = w, h
    roi = gray[scale_y1:scale_y2, scale_x1:scale_x2]
    rh, rw = roi.shape

    # 关键：比例尺文字与横线是纯黑(灰度≈0 的 UI 元素)，而地图再暗也有一层底噪。
    # 固定阈值(<50) / Otsu / 按分位数自适应，都会被暗色地图带跑（整行变黑、长度=整幅宽）。
    # 这里锚定 ROI 的最小值（就是比例尺自身的纯黑）再加一点余量，只保留真正的纯黑像素。
    thr = int(roi.min()) + 8

    # ========== 2. 把 100x20 再上下切成两块：上=数字，下=横线 ==========
    split = rh * 7 // 10
    text_roi, bar_roi = roi[:split], roi[split:]

    # ---------- 2a. 数字（OCR） ----------
    # 第一步：严格阈值只用来"定位"文字框（此时笔画很细，但位置足够准）
    tmask = (text_roi < thr).astype(np.uint8)
    # 去掉面积<3 的孤立噪点（地图上的杂色像素）
    n, lab, stats, _ = cv2.connectedComponentsWithStats(tmask, 8)
    keep = np.zeros_like(tmask)
    for i in range(1, n):
        if stats[i, cv2.CC_STAT_AREA] >= 3:
            keep[lab == i] = 1
    ys, xs = np.where(keep)

    scale_value = None
    scale_text = ""
    if len(xs):
        # 第二步：在框内用"灰度"处理，不要在原生分辨率上二值化 ——
        # 字形只有约 4x8 px，先二值化会丢掉抗锯齿信息，OCR 会把 1800 读成 1200/800。
        # 正确顺序是：对比拉伸 → 高倍灰度插值放大 → Otsu 反色。
        ty0, ty1 = max(0, int(ys.min()) - 1), min(split, int(ys.max()) + 2)
        tx0, tx1 = max(0, int(xs.min()) - 1), rw
        # 右边界直接顶到 ROI 末端：比例尺是右对齐的，数字右边只剩单位"m"，
        # 若按 bbox 收紧会把 m 切一半，OCR 就会把 1800 读成 180071/18007。
        sub = text_roi[ty0:ty1, tx0:tx1].astype(np.float32)
        lo, hi = float(sub.min()), float(np.percentile(sub, 70))
        sub = np.clip((sub - lo) / max(1.0, hi - lo) * 255, 0, 255).astype(np.uint8)
        sub = cv2.resize(sub, None, fx=12, fy=12, interpolation=cv2.INTER_CUBIC)
        _, sub = cv2.threshold(sub, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        sub = cv2.copyMakeBorder(255 - sub, 40, 40, 40, 40,
                                 cv2.BORDER_CONSTANT, value=0)
        scale_text = pytesseract.image_to_string(
            sub, config='--psm 7 -c tessedit_char_whitelist=0123456789').strip()
        numbers = re.findall(r'\d+', scale_text)
        if len(numbers) == 1:
            scale_value = int(numbers[0])

    # ---------- 2b. 横线（纯黑 + 只保留水平连续 >=10px 的段） ----------
    bmask = (bar_roi < thr).astype(np.uint8)
    hline = cv2.morphologyEx(bmask, cv2.MORPH_OPEN,
                             cv2.getStructuringElement(cv2.MORPH_RECT, (10, 1)))
    ys2, xs2 = np.where(hline)

    line_abs = None
    if len(xs2):
        line_abs = {
            'x1': scale_x1 + int(xs2.min()),
            'y': scale_y1 + split + int(ys2.mean()),
            'x2': scale_x1 + int(xs2.max()),
            'length_px': int(xs2.max() - xs2.min() + 1)
        }

    scale_info = {
        'value': scale_value,
        'bbox': (scale_x1, scale_y1, scale_x2 - scale_x1, scale_y2 - scale_y1),
        'threshold': thr,
        'line': line_abs
    }

    if debug:
        print(f"图片: {w}x{h}  阈值: {thr}")
        print(f"OCR: '{scale_text}' → {scale_value} m")
        if line_abs:
            print(f"线段: ({line_abs['x1']},{line_abs['y']})-({line_abs['x2']},{line_abs['y']})")
            print(f"长度: {line_abs['length_px']} px")
    return scale_info

def update_scale_data(screenshot):
    '''
    尝试从内存截图(PIL.Image)中识别比例尺并写入 MapState.scale_data / scale_width。
    成功返回 True，识别失败或数值不合理返回 False。
    '''
    scale_info = detect_scale(cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR))
    value = scale_info['value']
    line = scale_info['line']
    if not value or not line or not 300 <= value <= 10000 or line['length_px'] <= 0:
        print("比例尺识别失败：", value, line)
        return False
    MapState.scale_data = value
    MapState.scale_width = line['length_px']
    log(f"比例尺识别成功：{value} m / {line['length_px']} px")
    return True

def detect_ship_spawns(img,ship_min_area=80,debug=False):
    #检测战术地图中的舰船出生点图标
    h, w = img.shape[:2]

    # ========== 2. 舰船检测（HSV颜色分割）==========
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    
    # 红色掩码（色相 0 端为主）：模板实测红船只图标色相 0-2，实时截图的红船在 5-7（核心 6），
    # 故主段取 0-10：上界到 8 以后检出数量就不再变化，10 留足余量；早先的 0-4 对实时截图 0 命中。
    # 尾部原本 160-180 会误收粉/紫，按模板只保留红端回绕 176-180。
    # 已知残留：目标点 "B" 菱形标记色相为 4，会一并被当作红船检出，暂不做长宽比/形状过滤。
    mask_red1 = cv2.inRange(hsv, np.array([0, 100, 100]), np.array([10, 255, 255]))
    mask_red2 = cv2.inRange(hsv, np.array([176, 100, 100]), np.array([180, 255, 255]))
    mask_red = cv2.bitwise_or(mask_red1, mask_red2)
    
    # 蓝色掩码：模板实测蓝船只图标色相精确=113、饱和度≥210、明度≥80；
    # 原 100-130 且 S≥80 过宽，收紧为 113±5 且 S≥130，避免地图冷色地形被误判成船只。
    mask_blue = cv2.inRange(hsv, np.array([108, 130, 80]), np.array([118, 255, 255]))
    
    def find_ships(mask, min_area):
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        ships = []
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area >= min_area:
                x, y, bw, bh = cv2.boundingRect(cnt)
                ships.append({
                    'bbox': (x, y, bw, bh),
                    'area': float(area),
                    'center': (x + bw//2, y + bh//2)
                })
        return sorted(ships, key=lambda s: s['area'], reverse=True)
    
    red_ships = find_ships(mask_red, ship_min_area)
    blue_ships = find_ships(mask_blue, ship_min_area)
    
    if debug:
        print(f"图片: {w}x{h}")
        print(f"红色舰船: {len(red_ships)}艘 | 蓝色舰船: {len(blue_ships)}艘")
    
    return {
        'red_ships': red_ships,
        'blue_ships': blue_ships
    }

def update_spawn_data(screenshot,ship_min_area=80):
    '''
    尝试从内存截图(PIL.Image)中识别小地图上的舰船出生点图标并写入 ScreenState。
    以"检测到红色(敌方)出生点"为成功判据并返回 True，否则返回 False（蓝色会一并记录）。
    '''
    img = cv2.cvtColor(np.array(screenshot), cv2.COLOR_RGB2BGR)
    h, w = img.shape[:2]
    spawns = detect_ship_spawns(img, ship_min_area=ship_min_area)
    # 换算成小地图内的归一化坐标（与 ShipStatus.ship_position_x/y 同一套约定）
    red = [(c[0] / w, c[1] / h) for c in (s['center'] for s in spawns['red_ships'])]
    blue = [(c[0] / w, c[1] / h) for c in (s['center'] for s in spawns['blue_ships'])]
    if not (red and blue):
        print("出生点识别失败：未检测到红色(敌方)出生点")
        return False
    MapState.spawn_red = red
    MapState.spawn_blue = blue
    log(f"出生点识别成功：红 {len(red)} 个 / 蓝 {len(blue)} 个")
    return True