from headers.config import *
from headers.log import *
import PySimpleGUI as sg            #用于创建图形界面
import math
import base64
import io
from PIL import Image, ImageChops    #读取/处理出生点图标模板

# ============ 配置参数 ============
WIDTH, HEIGHT = MAP_REGION[2], MAP_REGION[3]
ARROW_LENGTH = 10
UPDATE_INTERVAL = 1000  # 毫秒
# 小地图比例尺：米/像素 = MapState.scale_data / MapState.scale_width
# （scale_data / scale_width 由 detect_scale_and_ships 的比例尺检测部分填入）
# 画布尺寸自动跟随 MAP_REGION（小地图截取区域），故像素偏移 1:1 可直接用


# ============ 出生点图标（预加载一次，供每帧复用） ============
# key 与 MapState.spawn_red / spawn_blue 对应；value = (base64 PNG 字符串, 宽, 高)
SPAWN_ICONS = {}


def prepare_spawn_icons():
    '''
    预加载 model/ 下的出生点模板图，做一次预处理后缓存到 SPAWN_ICONS：
    - 去掉黑色背景（按亮度转成全透明）；
    - 裁掉四周留白，只留图标本体；
    - 编码成 base64 PNG 字符串，供 Graph.draw_image(data=...) 反复使用。

    只需在演示窗口创建后调用一次；之后每帧重画都直接读缓存，不再触碰磁盘。
    重复调用会立即返回已有缓存。
    '''
    if SPAWN_ICONS:
        return SPAWN_ICONS
    for key, name in SPAWN_ICON_FILES.items():
        im = Image.open(current_dir + "/model/" + name + ".png").convert("RGBA")
        # 三通道取最大值作为亮度：不能直接用 convert("L")，
        # 蓝色轮廓的亮度只有 29，会被当成黑底一起剔掉
        r, g, b = im.convert("RGB").split()
        lum = ImageChops.lighter(ImageChops.lighter(r, g), b)
        # 黑色背景 -> 全透明（保留图标本体）
        im.putalpha(lum.point(lambda v: 255 if v >= 45 else 0))
        box = im.getbbox()
        if box:
            im = im.crop(box)
        buf = io.BytesIO()
        im.save(buf, format="PNG")
        SPAWN_ICONS[key] = (base64.b64encode(buf.getvalue()).decode(),
                            im.width, im.height)
    return SPAWN_ICONS


# ============ 绘制箭头函数 ============
def draw_arrow(canvas, cx, cy, direction, length=ARROW_LENGTH, 
               fill_color="#ffffff", line_color="#b8ce11"):
    """
    在画布上绘制箭头
    cx, cy: 像素坐标
    direction: 角度（0度朝右，逆时针增加）
    """
    angle_rad = math.radians(direction)
    
    # 箭头尖端
    tip_x = cx + length * math.cos(angle_rad)
    tip_y = cy - length * math.sin(angle_rad)
    
    # 两翼角度
    wing1_rad = angle_rad + math.radians(150)
    wing2_rad = angle_rad - math.radians(150)
    
    wing1_x = cx + length * 0.4 * math.cos(wing1_rad)
    wing1_y = cy - length * 0.4 * math.sin(wing1_rad)
    
    wing2_x = cx + length * 0.4 * math.cos(wing2_rad)
    wing2_y = cy - length * 0.4 * math.sin(wing2_rad)
    
    # 绘制填充箭头
    canvas.draw_polygon([(tip_x, tip_y), (wing1_x, wing1_y), (wing2_x, wing2_y)], 
                        fill_color, line_color, line_width=2)
    # 中心点
    #canvas.draw_circle((cx, cy), 4, fill_color='#00ff88', line_color='#ffffff', line_width=2)



def ship_status_text():
    '''
    把船只当前"在执行什么机动"翻译成人话。
    按"权限"从高到低只返回一条文案（演示界面同时只显示一条），
    "权限"即"能不能让其他子系统让位"，由代码中的门控关系拍板：

      1. 齐射转向         AimStatus.turning_to_shoot      ±1  ↳ 让 prevent_escape 让位
      2. 防止逃向出生点   ShipStatus.preventing_escape     ±1  ↳ 让位置类让位
      3. 防撞 / 防出界 / 防搁浅 / 机动中  ── 位置类，并列最低权限；
        防撞最急、排最前；机动中最常规、排最后。

    " +1 / -1" 直接照搬字段值，所以左右转方向由赋值处统一约定：
      -1 = 左转，+1 = 右转（见 config.py 注释）。
    都没有 → "自由"。
    '''
    if ShipStatus.preventing_aground:
        return '倒船防止搁浅'
    if ShipStatus.preventing_obstacles:
        return '防止撞障碍(%+d)' % ShipStatus.preventing_obstacles
    if ShipStatus.preventing_out:
        return '防止出界(%+d)' % ShipStatus.preventing_out
    if ShipStatus.moving_strategy:
        return '机动中(移动策略)'
    if AimStatus.turning_to_shoot:
        return '齐射转向(%+d)' % AimStatus.turning_to_shoot
    if ShipStatus.preventing_escape:
        return '防止逃向出生点(%+d)' % ShipStatus.preventing_escape




    return '自由'

sg.theme("Reddit")  # 设置主题
Script_UI_layout = [[sg.Text("WarThunder-Naval-Automation")],
            [sg.Text("设置舰船、脚本参数")],
            [sg.Text("（以下三个选项供参考）")],
            [sg.Text("船只类型"),sg.Button("驱逐"), sg.VSeperator(), sg.Button("轻巡"), sg.VSeperator(), sg.Button("重巡战列")],
            [sg.Text("典型转向时间"),sg.Input(default_text=ShipData.turntime, key='-VAR_t-', size=(5,1))],
            [sg.Text("典型前进时间"),sg.Input(default_text=ShipData.gotime, key='-VAR_g-', size=(5,1))],
            [sg.Text("典型装填时间"),sg.Input(default_text=ShipData.reloadtime, key='-VAR_r-', size=(5,1))],
            [sg.Text("连射轮数"),sg.Input(default_text=ShipData.shoot_round, key='-VAR_sr-', size=(5,1))],
            [sg.Text("行驶速度"),sg.Button("超速"),sg.VSeperator(),sg.Button("全速"),sg.VSeperator(),sg.Button("巡航")],
            [sg.Text("预计运行时间"),sg.Input(default_text=ProgramData.t_run, key='-VAR_tr-', size=(5,1))],
            [sg.Text("鼠标灵敏度x,y"),sg.Input(default_text=MouseSensitivity.sensibility_x, key='-VAR_sx-', size=(5,1)),
                                      sg.Input(default_text=MouseSensitivity.sensibility_y, key='-VAR_sy-', size=(5,1))],
            [sg.Button("更新参数"),sg.VSeparator(),sg.Button("开始运行"), sg.VSeperator(), sg.Button("显示数据")],
            [sg.Button("完成当前对局退出"), sg.VSeperator(), sg.Button("立即退出")]]

def sync_ship_vars(window):
    '''
    把 ShipData / ProgramData 当前"已生效"的值刷到全部六个输入框。
    只能由用户主动改参数的事件调用（套用舰种预设、点"更新参数"）：
    原来这几行写在 if/elif 链之外，任何事件（显示数据、开始运行、在输入框里回车、
    窗口重绘）都会拿旧值覆盖输入框，用户刚输入还没点"更新参数"的内容会被静默丢掉，
    而且框里显示的还是"已生效"的值，很容易误以为参数改成功了。
    '''
    for key, value in (('-VAR_t-', ShipData.turntime),
                       ('-VAR_g-', ShipData.gotime),
                       ('-VAR_r-', ShipData.reloadtime),
                       ('-VAR_sr-', ShipData.shoot_round)):
        window[key].update(value)


def Script_UI(window,event,values):
    # End program if user closes window or
    # presses the OK button
    if event == "开始运行" and not ProgramData.isRunning:
        ProgramData.isRunning = True
        log("开始运行")
        return "StartScript"
    elif event == "显示数据":
        print("显示程序识别的数据")
        return "StartDemonstrate"
    elif event == "完成当前对局退出":
        log("完成当前对局退出")
        ProgramData.isRunning=False
        return None
    elif event == "立即退出" or event == sg.WIN_CLOSED:
        return "EndScript"

    elif event == "驱逐" and not ProgramData.isRunning:
        ShipData.gotime = 40
        ShipData.turntime = 5
        ShipData.reloadtime = 4
        ShipData.shoot_round = 2
        ShipData.speed = 2
        ShipData.ship_type = 'destroyer'
        sync_ship_vars(window)
    elif event == "轻巡" and not ProgramData.isRunning:
        ShipData.gotime = 80
        ShipData.turntime = 15
        ShipData.reloadtime = 8
        ShipData.shoot_round = 1
        ShipData.speed = 0
        ShipData.ship_type = 'cruiser'
        sync_ship_vars(window)
    elif event == "重巡战列" and not ProgramData.isRunning:
        ShipData.gotime = 50
        ShipData.turntime = 32
        ShipData.reloadtime = 30
        ShipData.shoot_round = 1
        ShipData.speed = 0
        ShipData.ship_type = 'battleship'
        sync_ship_vars(window)
    elif event == "超速":
        ShipData.speed = 0
    elif event == "全速":
        ShipData.speed = 1
    elif event == "巡航":
        ShipData.speed = 2
        
    elif event == "更新参数":
        # 一个按钮读回全部输入框：非法输入保持原值（不报异常），最后统一回写，
        # 框里显示的就是"已生效"的值（例如输入 3 会被刷成 3.0）
        for key, target, name, cast in (('-VAR_t-', ShipData, 'turntime', float),
                                        ('-VAR_g-', ShipData, 'gotime', float),
                                        ('-VAR_r-', ShipData, 'reloadtime', float),
                                        ('-VAR_sr-', ShipData, 'shoot_round', int),
                                        ('-VAR_tr-', ProgramData, 't_run', float),
                                        ('-VAR_sx-', MouseSensitivity,'sensibility_x',float),
                                        ('-VAR_sy-', MouseSensitivity,'sensibility_y',float)):
            try:
                setattr(target, name, cast(values[key]))
                print('变量', name, '被修改为', getattr(target, name))
            except ValueError:
                print('输入的', name, '不是有效的数字')
        sync_ship_vars(window)






# 布局：画布 + 信息栏
demostrate_UI_layout = [
    [sg.Graph(
        canvas_size=(WIDTH, HEIGHT),
        graph_bottom_left=(0, 0),
        graph_top_right=(WIDTH, HEIGHT),
        background_color='#1a1a2e',
        key='-GRAPH-',
        enable_events=True,
        drag_submits=False
    )],
    [sg.Text('Ship_Position: (0.500, 0.500)', key='-Ship_Position-')],
    [sg.Text('Ship_Direction: 360°',key='-Ship_Direction-')],
    [sg.Text('Target_Position: (0.500, 0.500)', key='-Target_Position-')],
    [sg.Text('AimStatus.aim_direction: 360°',key='-Target_Direction-')],
    [sg.Text('Ship_Status: 自由', key='-Ship_Status-')],
]




def demostrate_UI(window,event,value):
    if event == sg.WINDOW_CLOSED:
        return "EndDemonstrate"

def update_demonstrate_UI(window):
    # 只更新各元素自身（window[key].update 是原地改控件内容），
    # 不重建布局、不触碰 values，也不影响其他元素
    graph = window['-GRAPH-']
    # 清空画布重画
    graph.erase()

    # ---- 出生点：用预加载好的图标标注（直接读缓存，不再读盘） ----
    for key, positions in (('red', MapState.spawn_red),
                           ('blue', MapState.spawn_blue)):
        if not positions or key not in SPAWN_ICONS:
            continue
        b64, iw, ih = SPAWN_ICONS[key]
        for sx, sy in positions:
            # 归一化坐标(y 向下) -> 画布像素坐标(y 向上)；
            # draw_image 的定位点是图片左上角，故减半宽、加上半高，使图标中心落在出生点上
            graph.draw_image(data=b64, location=(sx * WIDTH - iw / 2,
                                                 (1 - sy) * HEIGHT + ih / 2))

    # 初始值是 -1（未知），-1 为真但 0 为假，
    # 所以这里必须用 >= 0 判断，不能用 truthy 判断
    if 0<ShipStatus.ship_position_x<1 and 0<ShipStatus.ship_position_y<1:
        pixel_x = ShipStatus.ship_position_x * WIDTH
        pixel_y = (1 - ShipStatus.ship_position_y) * HEIGHT

        if ShipStatus.ship_direction >= 0:
            # ship_direction 是罗盘航向(0°=正北/向上, 90°=正东/向右)，
            # 而画布 y 轴向上，draw_arrow 的 0° 为向右、正角朝上，
            # 故需 -90 换算（否则箭头会整体顺时针偏 90°）
            draw_arrow(graph, pixel_x, pixel_y,
                       ShipStatus.ship_direction - 90, length=15)
        else:
            graph.draw_circle((pixel_x, pixel_y), 3, fill_color='#ffffff',
                              line_color='#b8ce11', line_width=1)

        # 逐个更新信息栏 Text 元素（信息栏显示的是归一化坐标本身，
        # 翻转只发生在像素坐标转换时）
        window['-Ship_Position-'].update(
            f'Ship_Position: ({ShipStatus.ship_position_x:.3f}, '
            f'{ShipStatus.ship_position_y:.3f})')
        window['-Ship_Direction-'].update(
            f'Ship_Direction: {ShipStatus.ship_direction:.0f}°')

        # ---- target 由 aim_direction(罗盘方位角, 0°=正北) + aim_distance(km)
        #      + 比例尺 scale_data / scale_width 推出 ----
        if (AimStatus.aim_direction!=None and AimStatus.aim_distance!=None and 
            0<=AimStatus.aim_direction<360 and 2<=AimStatus.aim_distance<10
                and MapState.scale_data and MapState.scale_width
                and 300 <= MapState.scale_data <= 10000
                and MapState.scale_width > 0):
            # 米/像素 -> km 换算成图上像素 -> 归一化偏移
            meters_per_px = MapState.scale_data / MapState.scale_width
            offset_px = AimStatus.aim_distance * 1000 / meters_per_px
            rad = math.radians(AimStatus.aim_direction)
            # 正北 = 小地图上方；小地图 y 轴向下，故 y 分量取负
            target_x = ShipStatus.ship_position_x + offset_px * math.sin(rad) / WIDTH
            target_y = ShipStatus.ship_position_y - offset_px * math.cos(rad) / HEIGHT

            # 画布像素坐标（y 轴向上）；目标超出小地图范围时贴边显示
            target_px = min(max(target_x * WIDTH, 4), WIDTH - 4)
            target_py = min(max((1 - target_y) * HEIGHT, 4), HEIGHT - 4)

            # 箭头方向按实际画出的连线取（目标贴边时也能正确指向）
            angle = math.degrees(math.atan2(pixel_y - target_py, target_px - pixel_x))
            arrow_cx = target_px - ARROW_LENGTH * math.cos(math.radians(angle))
            arrow_cy = target_py + ARROW_LENGTH * math.sin(math.radians(angle))
            graph.draw_line((pixel_x, pixel_y), (target_px, target_py),
                            color="#ce1111", width=1)
            draw_arrow(graph, arrow_cx, arrow_cy, angle,
                       fill_color="#ce1111",line_color="#ce1111",length=10)

            in_range = 0 <= target_x <= 1 and 0 <= target_y <= 1
            window['-Target_Position-'].update(
                f'Target_Position: ({target_x:.3f}, {target_y:.3f})'
                + ('' if in_range else ' 超出小地图'))
            window['-Target_Direction-'].update(
                f'Target_Direction: {AimStatus.aim_direction:.0f}° | '
                f'{AimStatus.aim_distance:.2f} km')
        else:
            window['-Target_Position-'].update('Target_Position: (未知)')
            window['-Target_Direction-'].update('Target_Direction: (未知)')

    # ---- 船只状态描述：每帧从 ShipStatus / AimStatus 翻译一次 ----
    window['-Ship_Status-'].update('Ship_Status: ' + ship_status_text())