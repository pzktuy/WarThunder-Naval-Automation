from headers.config import *
from headers.input_control import *
from headers.image_detection import *
import time,random,math,pyautogui

def attack_strategy(window):
    '''
    锁定目标并开火。
    返回 True -> 战局结束（已死亡/炮弹打光），调用方应退场
    返回 None -> 正常结束（附近长时间没有目标）
    '''
    i_findtarget=0
    i_shoottarget=0
    while True:
        #游戏窗口不在前台（切出去调参数等）：跳过这一轮，一个键鼠都不发，回到游戏后继续打
        if not window_active(window):
            time.sleep(2)
            continue
        target_find,target_class =findtarget()
        if target_find and i_shoottarget<6:
            print("shell round",AimStatus.i)
            AimStatus.normal_y_correction = 17
            AimStatus.shoot_distance_max = 7
            AimStatus.shoot_distance_min = 2
            if target_class == 'small':
                AimStatus.normal_y_correction = 0
                AimStatus.shoot_distance_max = 4
                AimStatus.shoot_distance_min = 0
            i_findtarget=0
            attackPattern(debug=False,aim_y_correction=AimStatus.normal_y_correction)

            if AimStatus.decide_to_shoot:
                AimStatus.shoot_fail = 0
                i_shoottarget += 1
                AimStatus.i += 1
            else:
                if AimStatus.shoot_fail > 5:
                    AimStatus.decide_to_shoot = True
                    AimStatus.shoot_fail = 0
                else:
                    AimStatus.shoot_fail += 1
                    find_other_target()

        else:
            print("切换目标")
            AimStatus.locking_target = False
            AimStatus.turned_to_shoot = False
            AimStatus.decide_to_shoot = False

            i_shoottarget=0
            i_findtarget+=1
            pressWithDelay('x')
            time.sleep(0.2)
        if i_findtarget>5:
            print("长时间未找到目标")
            break

    ScreenState.screenshot = getScreen(window)
    if AimStatus.i > 150:
        # try to escape
        log("炮弹应该打光了/出bug了")
        return True
    died, _ = hasImage("enteragain",0.99, ScreenState.screenshot)
    if not died:
        died, _ = hasImage("youdied", 0.95, ScreenState.screenshot)
    if died:
        log("已死亡，返回主界面中")
        return True
    else:
        print("只是附近没有目标")
        time.sleep(10)

def findtarget(debug=False):
    '''
    寻找目标，若未发现目标则向右转动视角
    '''
    ScreenState.target_status = pyautogui.screenshot(region=(93, 176, 47, 47))
    if debug:
        ScreenState.target_status.save(current_dir+'/temp/target_status.png')
    target_status_red = Get_Color_IMG(ScreenState.target_status,(251, 68, 53),(255,255,255),60)
    dot_found, dot_pos = hasImage('reddot', threshold=0.93, location=target_status_red)
    if dot_found:
        
        #判断目标类型
        ScreenState.target_crew_status = pyautogui.screenshot(region=(998,207,53,14))
        if debug:
            ScreenState.target_crew_status.save(current_dir+'/temp/target_crew_status.png')
        target_crew = recognize_target_crew_status(ScreenState.target_crew_status,debug=True)
        target_class = 'normal'
        if target_crew:
            if target_crew[1]<=100:
                #is small ship
                target_class = 'small'
            elif target_crew[1]>=800:
                target_class = 'large'
                print('too large ship')
                return False,None

        pressWithDelay('=')
        AimStatus.locking_target = True
        target_x = dot_pos[0]-47/2
        target_y = dot_pos[1]-47/2
        
        AimStatus.aim_direction = math.degrees(math.atan2(target_x, -target_y)) % 360
        print("敌舰方向",AimStatus.aim_direction)
        if not (ShipStatus.preventing_out or ShipStatus.preventing_obstacles
            or ShipStatus.preventing_aground or ShipStatus.moving_strategy
            or AimStatus.turned_to_shoot):
            if ShipStatus.ship_direction!=-1:
                target_to_ship = (AimStatus.aim_direction-ShipStatus.ship_direction+360) % 360
                print("我舰方向",ShipStatus.ship_direction,"相对方向",target_to_ship)
                if 0<=target_to_ship<40 or 180< target_to_ship<220:
                    AimStatus.turning_to_shoot = -1
                    print("左转齐射")
                    pressWithDelay('a',d=3)
                    AimStatus.turning_to_shoot = 0
                elif 320<target_to_ship<360 or 140 < target_to_ship<=180:
                    AimStatus.turning_to_shoot = +1
                    print("右转齐射")
                    pressWithDelay('d',d=3)
                    AimStatus.turning_to_shoot = 0
                else:
                    AimStatus.turned_to_shoot = True
        return True,target_class
    else:
        AimStatus.locking_target = False
        AimStatus.turned_to_shoot = False
        send_input_mouse(1200+400*(random.random()-0.5),0,speed=1500)
        pressWithDelay('x')
        #time.sleep(1)
        return False,None

def find_other_target():
    print("目标不合格，寻找其他目标")
    send_input_mouse((500+200*(random.random()-0.5))*
                     AimStatus.shoot_fail*(-1)**AimStatus.shoot_fail,
                     0,
                     speed=300)
    pressWithDelay('x')

#截屏左上角坐标、长度高度
x00,y00,x01,y01=356,385,544,18
#准心位置
x0,y0=643,395
range_time=8

def attackPattern(debug=False,aim_y_correction = 17):
    '''
    open fire at the enemy
    '''
    correction_x = 0
    correction_y = 0
    shoot_time = 0

    pressWithDelay('shift')
    pressWithDelay('=')
    pressWithDelay('x')

    #由于锁定位置不准，需要预先调整
    correction_x += 30*(random.random()-0.5)
    if ShipStatus.ship_direction>=0 and AimStatus.aim_direction>=0:
        if debug:print("find ShipStatus.ship_direction and AimStatus.aim_direction")
        correction_y += aim_y_correction + 7*math.cos(math.radians(ShipStatus.ship_direction-AimStatus.aim_direction))
    else:
        correction_y +=aim_y_correction+5*(random.random()-0.5)
    send_input_mouse(correction_x,correction_y,speed=300)
    correction_x=0
    correction_y=0
    time.sleep(1)

    #检查游戏是否计算出提前量（v_pos 直接接住匹配结果，防被其它线程的匹配覆盖）
    ScreenState.aim_scr = pyautogui.screenshot(region=(x00,y00,x01,y01))
    if debug:
        ScreenState.aim_scr.save(current_dir+'/temp/aim_scr.png')
    aim_red = Get_Color_IMG(ScreenState.aim_scr,(231, 132, 134),(255,255,255),55)
    v_found, v_pos = hasImage( 'v_red_filtered' , threshold=0.99, location=aim_red,debug=debug)
    if v_found:
        find_shoot_position = True
    else:
        aim_green = Get_Color_IMG(ScreenState.aim_scr,(99, 235, 102),(255,255,255),80)
        v_found, v_pos = hasImage( 'v_green_filtered' , threshold=0.98, location=aim_green,debug=debug)
        if v_found:
            find_shoot_position = True
        else:
            find_shoot_position = False

    #决策是否射击：过远则不射击，过近则下压炮口
    ScreenState.aim_distance_scr = pyautogui.screenshot(region=(617,423,32,13))
    if debug:
        ScreenState.aim_distance_scr.save(current_dir+'/temp/aim_distance_scr.png')
    AimStatus.aim_distance = get_aim_distance(ScreenState.aim_distance_scr)
    print("target distance",AimStatus.aim_distance,"km")
    if AimStatus.aim_distance == None:
        AimStatus.decide_to_shoot = True
    elif AimStatus.shoot_distance_max < AimStatus.aim_distance < 80:
        # 这里只否决本次射击，不再自己 +1：失败计数统一由 attack_strategy 每轮 +1。
        # 两处都加会让"过远"时每轮 +2 —— 既把"连续 6 次"缩成约 3 轮，
        # 又让 find_other_target 的 (-1)**shoot_fail 恒为偶数（永远只往右扫，左右交替失效）。
        AimStatus.decide_to_shoot = False
        print("距离过远，放弃攻击")
    elif 0<AimStatus.aim_distance <AimStatus.shoot_distance_min:
        print("距离较近，额外压低炮口")
        AimStatus.decide_to_shoot = True
        correction_y += 15*MouseSensitivity.sensibility_y
    else:
        AimStatus.decide_to_shoot = True
    
    if AimStatus.decide_to_shoot and find_shoot_position:
        x1,y1=v_pos
        correction_x += (x1+x00-x0+6*(random.random()-0.5))/0.7*MouseSensitivity.sensibility_x
        shoot_time = ShipData.shoot_round * ShipData.reloadtime

    elif AimStatus.decide_to_shoot:
        if ShipStatus.ship_direction>=0 and AimStatus.aim_direction>=0:
            if AimStatus.aim_distance is not None:
                #print("find ShipStatus.ship_direction and AimStatus.aim_direction and aim_distance")
                correction_x += (15*AimStatus.aim_distance*
                                 math.sin(math.radians(-ShipStatus.ship_direction+AimStatus.aim_direction))*
                                 MouseSensitivity.sensibility_x)
            else:
                #print("find ShipStatus.ship_direction and AimStatus.aim_direction")
                correction_x += (100*
                                 math.sin(math.radians(-ShipStatus.ship_direction+AimStatus.aim_direction))*
                                 MouseSensitivity.sensibility_x)
        shoot_time = range_time
    else:
        pressWithDelay('shift')
        return
    send_input_mouse(correction_x,correction_y,speed=500)
    click()
    click(duration=shoot_time)
    pressWithDelay('shift')