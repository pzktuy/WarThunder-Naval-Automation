from headers.config import *
from headers.log import *
from headers.input_control import *
from headers.image_detection import *
import time,math,pyautogui
def hide_obstacles(stop_event, debug=False):
    #躲避障碍：若触礁告警则左转
    #debug=True 时把每轮的原始截图存到 temp/nav_scr.png（调试用，默认关闭，省一次磁盘写）
    while not stop_event.is_set():
        ScreenState.nav_scr = pyautogui.screenshot(region=(480,233,320,320))
        if debug:
            ScreenState.nav_scr.save(current_dir+"/temp/nav_scr.png")
        ScreenState.nav_scr = Get_Color_IMG(ScreenState.nav_scr,(255,255,255),(0,0,0),30)
        obstacle, _ = hasImage('obstacles',0.90, location=ScreenState.nav_scr)
        if obstacle and not ShipStatus.preventing_aground:
            ShipStatus.preventing_obstacles = -1
            print('发现障碍物，默认左转')
            pressWithDelay('a',5,0)
            ShipStatus.preventing_obstacles = 0
        else:
            time.sleep(5)

def prevent_aground(stop_event, debug=False):
    '''
    检测是否已触礁
    debug=True 时把每轮的原始截图存到 temp/nav_agr_scr.png（调试用，默认关闭，省一次磁盘写）
    '''
    while not stop_event.is_set():
        if ShipStatus.preventing_obstacles:
            time.sleep(5)
            continue
        ScreenState.nav_agr_scr = pyautogui.screenshot(region=(450,450,300,250))
        if debug:
            ScreenState.nav_agr_scr.save(current_dir+"/temp/nav_agr_scr.png")
        ScreenState.nav_agr_scr = Get_Color_IMG(ScreenState.nav_agr_scr,(200,30,30),(255,255,255),100)
        aground, _ = hasImage('aground',0.97, location=ScreenState.nav_agr_scr)
        if aground:
            print("船只搁浅，后退")
            pressWithDelay('s',d=3)
            ShipStatus.preventing_aground = True
            for i in range(5):
                if not stop_event.is_set():
                    time.sleep(4)
                else:
                    ShipStatus.preventing_aground = False
                    return
            pressWithDelay('w',d=3,t=1)
            ShipStatus.preventing_aground = False
            for i in range(ShipData.speed):
                pressWithDelay('s',d=0.05)
        else:
            for i in range(6):
                if not stop_event.is_set():
                    time.sleep(5)
                else:
                    return

def recommend_turn(x, y, direction_deg, margin=0.05):
    """
    根据船在小地图中的位置与航向，分四条边界判断是否驶出并建议转向。

    参数
    ----
    x, y : float              船在小地图中的相对位置
    direction_deg : float     当前航向（度）
    margin : float            离边缘的告警阈值，默认 0.05

    返回
    ----
    str 或 None  ("left" / "right" / None)
        只有四条边全部检查完毕、且都安全时，才返回 None；
        任一条边需要转向则立即返回该建议（角落处可能由更靠近危险边的判定给出）。
    """
    d = direction_deg % 360

    # 四条边界： (是否靠近该边, 指向地图内部的方向角)
    edges = [
        (x > 1.0 - margin, 270),   # 右边缘：内部在左
        (x < margin, 90),           # 左边缘：内部在右
        (y < margin, 180),         # 上边缘：内部在下
        (y > 1.0 - margin, 0),    # 下边缘：内部在上
    ]

    for near, base in edges:
        if not near:
            continue
        advice = _edge_advice(d, base)
        if advice is not None:
            return advice   # 找到需要转向的边，立即返回

    # 所有边都检查过且都安全，才返回 None
    return None

def _edge_advice(d, base):
    """
    某条边界处的转向建议。

    base : 指向地图内部的方向角（度）。
    以 base 为中心、±80° 为朝内安全扇区；扇区外则把航向朝 base 靠拢：
        diff = (d - base) 归一化到 [-180, 180)
        diff > 0 -> 航向在 base 的逆时针侧 -> 需顺时针(右转)靠回内部
        diff < 0 -> 航向在 base 的顺时针侧 -> 需逆时针(左转)靠回内部
    """
    diff = (d - base + 180) % 360 - 180   # 归一化到 [-180, 180)
    if abs(diff) < 80:
        return None
    return "left" if diff > 0 else "right"

def prevent_out(stop_event, debug=False):
    '''
    避免舰船驶出边界
    debug=True 时把每轮的小地图截图存到 temp/battle_map.png（调试用，默认关闭，省一次磁盘写）
    '''
    while not stop_event.is_set():

        MapState.battle_map = pyautogui.screenshot(region=MAP_REGION)
        # 比例尺缺失时尝试识别，每局最多尝试 3 次（成功或超次数后不再尝试）
        if MapState.scale_data is None or MapState.scale_width is None:
            if MapState.scale_try < 3:
                MapState.scale_try += 1
                print(f"第 {MapState.scale_try} 次尝试识别比例尺")
                update_scale_data(MapState.battle_map)
        # 出生点缺失时尝试识别，每局最多尝试 3 次（一旦成功即停止尝试）
        if MapState.spawn_red is None and MapState.spawn_blue is None:
            if MapState.spawn_try < 3:
                MapState.spawn_try += 1
                print(f"第 {MapState.spawn_try} 次尝试识别出生点")
                update_spawn_data(MapState.battle_map)
        if debug:
            MapState.battle_map.save(current_dir+"/temp/battle_map.png")
        result = detect_arrow(MapState.battle_map,"ship_icon_in_map")
        if result:
            ShipStatus.ship_position_x,ShipStatus.ship_position_y = result['relative']
            ShipStatus.ship_direction = result['direction_deg']
            if ShipStatus.preventing_obstacles or ShipStatus.preventing_aground:
                time.sleep(5)
                continue
            print("ship locatio:",ShipStatus.ship_position_x,ShipStatus.ship_position_y)
            print("ship direction:",ShipStatus.ship_direction)
            advice = recommend_turn(ShipStatus.ship_position_x,ShipStatus.ship_position_y,
                                    ShipStatus.ship_direction,margin=0.1)
            if advice == "left":
                print("即将脱离战场，左转")
                ShipStatus.preventing_out = -1
                pressWithDelay('a',10.0)
                ShipStatus.preventing_out = 0
                continue
            elif advice == "right":
                print("即将脱离战场，右转")
                ShipStatus.preventing_out = +1
                pressWithDelay('d',10.0)
                ShipStatus.preventing_out = 0
                continue
        for i in range(6):
            if not stop_event.is_set():
                time.sleep(5)
            else:
                return

def prevent_escape(stop_event):
    '''
    朝向红方(敌方)出生点转向

    仅当红方出生点、本舰位置与航向都能探测到，且没有其他机动动作、也没在齐射转向时才探测：
        本舰航向与"出生点平均位置"方位的夹角 > 45° -> 向该侧转向 5 秒后立即重新探测
        夹角 <= 45° 或探测条件不满足               -> 统一休眠一分钟
    转向标记 ShipStatus.preventing_escape：0 未转向，-1 左转，+1 右转
    '''
    while not stop_event.is_set():
        # "没有其他动作"沿用 ship_attack 里那套判据；
        # 再加一条：开火流程正在为齐射转向时（AimStatus.turning_to_shoot != 0）必须让出舵，
        # 否则会和 findtarget() 里那 3 秒的 a/d 抢舵，把准星带偏
        if (MapState.spawn_red
                and 0 <= ShipStatus.ship_position_x <= 1
                and 0 <= ShipStatus.ship_position_y <= 1
                and ShipStatus.ship_direction >= 0
                and AimStatus.turning_to_shoot == 0
                and not (ShipStatus.preventing_out or ShipStatus.preventing_obstacles
                         or ShipStatus.preventing_aground or ShipStatus.moving_strategy)):
            # 红方出生点的平均位置（归一化坐标，y 向下）
            avg_x = sum(p[0] for p in MapState.spawn_red) / len(MapState.spawn_red)
            avg_y = sum(p[1] for p in MapState.spawn_red) / len(MapState.spawn_red)
            # 本舰 -> 出生点平均位置的罗盘方位角（0=正北=小地图上方，90=正东=右）
            bearing = math.degrees(math.atan2(avg_x - ShipStatus.ship_position_x,
                                              ShipStatus.ship_position_y - avg_y)) % 360
            # 与当前航向的夹角，归一化到 [-180, 180)：>0 在右舷(顺时针)，<0 在左舷
            diff = (bearing - ShipStatus.ship_direction + 180) % 360 - 180

            if abs(diff) > 45:
                if diff > 0:
                    print("朝向红方出生点，右转")
                    ShipStatus.preventing_escape = +1
                    pressWithDelay('d', 5.0)
                else:
                    print("朝向红方出生点，左转")
                    ShipStatus.preventing_escape = -1
                    pressWithDelay('a', 5.0)
                ShipStatus.preventing_escape = 0
                continue        # 转向完成，立刻重新探测，不休眠
            else:
                print(f"已朝向红方出生点（偏差 {diff:.0f}°），休眠 60s")
        else:
            print("出生点或本舰位姿未知、或有其他机动动作，休眠 60s")
        # 偏差较小或探测条件不满足：统一休眠 60s
        for i in range(12):
            if stop_event.is_set():
                return
            time.sleep(5)
    return

def move_strategy(stop_event):
    '''
    主动行动规律：先直行然后右转巡航
    '''
    ShipStatus.moving_strategy = True
    pressWithDelay('w',d=0.5)
    for i in range(int(ShipData.gotime/5)):
        if (stop_event.is_set() or ShipStatus.preventing_obstacles or
                ShipStatus.preventing_aground or ShipStatus.preventing_out):
            break
        else:
            time.sleep(5)
    for i in range(int(ShipData.turntime/10)):
        if (stop_event.is_set() or ShipStatus.preventing_obstacles or
                ShipStatus.preventing_aground or ShipStatus.preventing_out):
            break
        else:
            pressWithDelay('d',10,0.1)
    for i in range(ShipData.speed):
        pressWithDelay('s',d=0.05)
    ShipStatus.moving_strategy = False
    return
